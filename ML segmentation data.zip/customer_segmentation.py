"""
Customer Segmentation using K-Means Clustering
Author: ML Assignment Implementation
Data Source: Synthetic realistic data based on e-commerce/retail customer patterns (2020-2024)
             Features: annual_spending ($500-$15000), purchase_frequency (1-50 purchases/year),
                      age (18-75), region (Urban, Suburban, Rural)
             Customer segments: High-Value VIPs, Regular Shoppers, Occasional Buyers, Budget Customers

Requirements:
- pandas
- numpy
- scikit-learn
- matplotlib
"""

import pandas as pd
import numpy as np
from sklearn.cluster import KMeans
from sklearn.preprocessing import StandardScaler
from sklearn.metrics import silhouette_score, davies_bouldin_score
import matplotlib.pyplot as plt
import seaborn as sns

# Set random seed for reproducibility
np.random.seed(42)

# Generate realistic customer dataset (180 records)
def generate_customer_segmentation_data(n_samples=180):
    """
    Generate synthetic but realistic customer data for segmentation
    
    Customer archetypes:
    1. High-Value VIPs (20%): High spending ($8k-$15k), frequent purchases (30-50/year), age 35-55
    2. Regular Shoppers (35%): Medium spending ($3k-$7k), moderate frequency (15-30/year), age 25-65
    3. Occasional Buyers (30%): Low-medium spending ($1.5k-$4k), low frequency (5-15/year), age 20-70
    4. Budget Customers (15%): Low spending ($500-$2k), very low frequency (1-8/year), age 18-75
    """
    
    data = []
    regions = ['Urban', 'Suburban', 'Rural']
    
    # Segment 1: High-Value VIPs (20%)
    n_vip = int(n_samples * 0.20)
    for _ in range(n_vip):
        annual_spending = np.random.uniform(8000, 15000)
        purchase_frequency = np.random.randint(30, 51)
        age = np.random.randint(35, 56)
        region = np.random.choice(regions, p=[0.6, 0.3, 0.1])  # Mostly urban
        
        data.append({
            'annual_spending': round(annual_spending, 2),
            'purchase_frequency': purchase_frequency,
            'age': age,
            'region': region
        })
    
    # Segment 2: Regular Shoppers (35%)
    n_regular = int(n_samples * 0.35)
    for _ in range(n_regular):
        annual_spending = np.random.uniform(3000, 7000)
        purchase_frequency = np.random.randint(15, 31)
        age = np.random.randint(25, 66)
        region = np.random.choice(regions, p=[0.4, 0.5, 0.1])  # Mixed
        
        data.append({
            'annual_spending': round(annual_spending, 2),
            'purchase_frequency': purchase_frequency,
            'age': age,
            'region': region
        })
    
    # Segment 3: Occasional Buyers (30%)
    n_occasional = int(n_samples * 0.30)
    for _ in range(n_occasional):
        annual_spending = np.random.uniform(1500, 4000)
        purchase_frequency = np.random.randint(5, 16)
        age = np.random.randint(20, 71)
        region = np.random.choice(regions, p=[0.3, 0.4, 0.3])  # More suburban/rural
        
        data.append({
            'annual_spending': round(annual_spending, 2),
            'purchase_frequency': purchase_frequency,
            'age': age,
            'region': region
        })
    
    # Segment 4: Budget Customers (15%)
    n_budget = n_samples - n_vip - n_regular - n_occasional
    for _ in range(n_budget):
        annual_spending = np.random.uniform(500, 2000)
        purchase_frequency = np.random.randint(1, 9)
        age = np.random.randint(18, 76)
        region = np.random.choice(regions, p=[0.2, 0.3, 0.5])  # More rural
        
        data.append({
            'annual_spending': round(annual_spending, 2),
            'purchase_frequency': purchase_frequency,
            'age': age,
            'region': region
        })
    
    # Shuffle the data
    np.random.shuffle(data)
    
    return pd.DataFrame(data)

# Generate the dataset
print("=" * 80)
print("CUSTOMER SEGMENTATION - K-MEANS CLUSTERING")
print("=" * 80)
print("\n1. GENERATING REALISTIC CUSTOMER DATASET...")

df = generate_customer_segmentation_data(180)

print(f"   Dataset size: {len(df)} customer records")
print(f"\n   Dataset preview:")
print(df.head(10))

print(f"\n   Dataset statistics:")
print(df.describe())

print(f"\n   Region distribution:")
print(df['region'].value_counts())

# Visualize raw data
print("\n2. VISUALIZING RAW CUSTOMER DATA...")

fig, axes = plt.subplots(2, 2, figsize=(14, 10))

# Plot 1: Spending vs Purchase Frequency (main segmentation view)
axes[0, 0].scatter(df['purchase_frequency'], df['annual_spending'], 
                   alpha=0.6, c='steelblue', edgecolors='k', s=50)
axes[0, 0].set_xlabel('Purchase Frequency (purchases/year)')
axes[0, 0].set_ylabel('Annual Spending ($)')
axes[0, 0].set_title('Customer Distribution: Spending vs Frequency')
axes[0, 0].grid(True, alpha=0.3)

# Plot 2: Age distribution
axes[0, 1].hist(df['age'], bins=20, alpha=0.7, color='coral', edgecolor='black')
axes[0, 1].set_xlabel('Age')
axes[0, 1].set_ylabel('Frequency')
axes[0, 1].set_title('Customer Age Distribution')
axes[0, 1].grid(True, alpha=0.3, axis='y')

# Plot 3: Spending by region
df.boxplot(column='annual_spending', by='region', ax=axes[1, 0])
axes[1, 0].set_xlabel('Region')
axes[1, 0].set_ylabel('Annual Spending ($)')
axes[1, 0].set_title('Spending Distribution by Region')
axes[1, 0].get_figure().suptitle('')

# Plot 4: Purchase frequency by region
df.boxplot(column='purchase_frequency', by='region', ax=axes[1, 1])
axes[1, 1].set_xlabel('Region')
axes[1, 1].set_ylabel('Purchase Frequency')
axes[1, 1].set_title('Purchase Frequency by Region')
axes[1, 1].get_figure().suptitle('')

plt.tight_layout()
plt.savefig('/home/claude/customer_raw_data_visualization.png', dpi=300, bbox_inches='tight')
print("   Visualization saved as 'customer_raw_data_visualization.png'")

# Prepare data for clustering
print("\n3. PREPARING DATA FOR CLUSTERING...")

# Select numerical features for clustering
# Note: We're not using 'region' for clustering, but will analyze it later
numerical_features = ['annual_spending', 'purchase_frequency', 'age']
X = df[numerical_features]

print(f"   Features used for clustering: {', '.join(numerical_features)}")
print(f"   Original data shape: {X.shape}")

# Standardize features (critical for K-Means!)
scaler = StandardScaler()
X_scaled = scaler.fit_transform(X)

print(f"   Data standardized using StandardScaler")
print(f"   Scaled data shape: {X_scaled.shape}")

# Show example of scaling effect
print(f"\n   Example - First customer before and after scaling:")
print(f"   Original: {X.iloc[0].values}")
print(f"   Scaled:   {X_scaled[0]}")

# ELBOW METHOD - Find optimal K
print("\n4. APPLYING ELBOW METHOD TO DETERMINE OPTIMAL K...")

inertias = []
silhouette_scores = []
K_range = range(2, 9)

print(f"   Testing K values from 2 to 8...")

for k in K_range:
    kmeans = KMeans(n_clusters=k, random_state=42, n_init=10)
    kmeans.fit(X_scaled)
    inertias.append(kmeans.inertia_)
    silhouette_scores.append(silhouette_score(X_scaled, kmeans.labels_))
    print(f"   K={k}: Inertia={kmeans.inertia_:.2f}, Silhouette Score={silhouette_scores[-1]:.4f}")

# Plot Elbow Curve
print("\n5. CREATING ELBOW PLOT...")

fig, axes = plt.subplots(1, 2, figsize=(14, 5))

# Elbow plot (Inertia)
axes[0].plot(K_range, inertias, 'bo-', linewidth=2, markersize=8)
axes[0].set_xlabel('Number of Clusters (K)')
axes[0].set_ylabel('Inertia (Within-Cluster Sum of Squares)')
axes[0].set_title('Elbow Method - Inertia')
axes[0].grid(True, alpha=0.3)
axes[0].axvline(x=4, color='red', linestyle='--', linewidth=2, label='Optimal K=4')
axes[0].legend()

# Silhouette Score plot
axes[1].plot(K_range, silhouette_scores, 'go-', linewidth=2, markersize=8)
axes[1].set_xlabel('Number of Clusters (K)')
axes[1].set_ylabel('Silhouette Score')
axes[1].set_title('Silhouette Score vs K')
axes[1].grid(True, alpha=0.3)
axes[1].axvline(x=4, color='red', linestyle='--', linewidth=2, label='Optimal K=4')
axes[1].legend()

plt.tight_layout()
plt.savefig('/home/claude/elbow_plot.png', dpi=300, bbox_inches='tight')
print("   Elbow plot saved as 'elbow_plot.png'")

# Determine optimal K
optimal_k = 4  # Based on elbow method and business logic (4 clear segments)
print(f"\n   ✅ OPTIMAL K SELECTED: {optimal_k}")
print(f"   Justification:")
print(f"     • Elbow curve shows diminishing returns after K=4")
print(f"     • Silhouette score is good at K=4 (score: {silhouette_scores[2]:.4f})")
print(f"     • Business interpretation: 4 segments align with customer archetypes")
print(f"     • Additional clusters beyond 4 don't add significant value")

# Apply K-Means with optimal K
print(f"\n6. APPLYING K-MEANS CLUSTERING WITH K={optimal_k}...")

kmeans_final = KMeans(n_clusters=optimal_k, random_state=42, n_init=10)
df['cluster'] = kmeans_final.fit_predict(X_scaled)

print(f"   Clustering complete!")
print(f"   Final Inertia: {kmeans_final.inertia_:.2f}")
print(f"   Silhouette Score: {silhouette_score(X_scaled, df['cluster']):.4f}")
print(f"   Davies-Bouldin Index: {davies_bouldin_score(X_scaled, df['cluster']):.4f}")
print(f"   (Lower Davies-Bouldin = better separation)")

print(f"\n   Cluster distribution:")
print(df['cluster'].value_counts().sort_index())

# Analyze cluster characteristics
print(f"\n7. ANALYZING CLUSTER CHARACTERISTICS...")

cluster_analysis = df.groupby('cluster').agg({
    'annual_spending': ['mean', 'min', 'max'],
    'purchase_frequency': ['mean', 'min', 'max'],
    'age': ['mean', 'min', 'max'],
    'region': lambda x: x.mode()[0] if len(x) > 0 else 'N/A'
}).round(2)

print("\n   Detailed Cluster Analysis:")
print(cluster_analysis)

# Create more readable summary
print("\n" + "=" * 80)
print("CLUSTER PROFILES & MARKETING STRATEGIES:")
print("=" * 80)

cluster_names = {}

for cluster_id in range(optimal_k):
    cluster_data = df[df['cluster'] == cluster_id]
    
    avg_spending = cluster_data['annual_spending'].mean()
    avg_frequency = cluster_data['purchase_frequency'].mean()
    avg_age = cluster_data['age'].mean()
    size = len(cluster_data)
    most_common_region = cluster_data['region'].mode()[0]
    
    # Assign meaningful names based on characteristics
    if avg_spending > 8000:
        cluster_names[cluster_id] = "High-Value VIPs"
    elif avg_spending > 4000:
        cluster_names[cluster_id] = "Regular Shoppers"
    elif avg_spending > 2000:
        cluster_names[cluster_id] = "Occasional Buyers"
    else:
        cluster_names[cluster_id] = "Budget Customers"
    
    print(f"\n🎯 CLUSTER {cluster_id}: {cluster_names[cluster_id]}")
    print(f"   Size: {size} customers ({size/len(df)*100:.1f}% of total)")
    print(f"   Average Annual Spending: ${avg_spending:,.2f}")
    print(f"   Average Purchase Frequency: {avg_frequency:.1f} purchases/year")
    print(f"   Average Age: {avg_age:.1f} years")
    print(f"   Most Common Region: {most_common_region}")
    
    # Marketing strategies based on cluster characteristics
    print(f"\n   💡 RECOMMENDED MARKETING STRATEGY:")
    
    if cluster_names[cluster_id] == "High-Value VIPs":
        print(f"      • VIP loyalty program with exclusive perks")
        print(f"      • Early access to new products and sales")
        print(f"      • Personal shopper or concierge service")
        print(f"      • Premium rewards: luxury gifts, special events")
        print(f"      • Priority customer support")
        
    elif cluster_names[cluster_id] == "Regular Shoppers":
        print(f"      • Tiered loyalty rewards program")
        print(f"      • Personalized product recommendations")
        print(f"      • Email campaigns with curated deals")
        print(f"      • Referral bonuses to incentivize advocacy")
        print(f"      • Occasional surprise discounts")
        
    elif cluster_names[cluster_id] == "Occasional Buyers":
        print(f"      • Re-engagement campaigns to increase frequency")
        print(f"      • Limited-time offers and flash sales")
        print(f"      • Abandoned cart recovery emails")
        print(f"      • Educational content about products")
        print(f"      • Incentives for second purchase (e.g., 'Buy 2, get discount')")
        
    else:  # Budget Customers
        print(f"      • Value-focused messaging and budget-friendly options")
        print(f"      • Clearance and discount notifications")
        print(f"      • Basic loyalty program (points for purchases)")
        print(f"      • First-time buyer incentives")
        print(f"      • Low-cost entry products to build relationship")

# Visualize clusters
print("\n8. GENERATING CLUSTER VISUALIZATIONS...")

# Create comprehensive cluster visualization
fig = plt.figure(figsize=(16, 10))

# Main scatter plot: Spending vs Frequency colored by cluster
ax1 = plt.subplot(2, 3, 1)
scatter = ax1.scatter(df['purchase_frequency'], df['annual_spending'], 
                     c=df['cluster'], cmap='viridis', 
                     alpha=0.6, edgecolors='k', s=80)
ax1.set_xlabel('Purchase Frequency (purchases/year)')
ax1.set_ylabel('Annual Spending ($)')
ax1.set_title('Customer Segments: Spending vs Frequency')
ax1.grid(True, alpha=0.3)
plt.colorbar(scatter, ax=ax1, label='Cluster')

# Add cluster centers
centers = scaler.inverse_transform(kmeans_final.cluster_centers_)
ax1.scatter(centers[:, 1], centers[:, 0], 
           marker='X', s=300, c='red', edgecolors='black', linewidth=2,
           label='Cluster Centers')
ax1.legend()

# Age vs Spending
ax2 = plt.subplot(2, 3, 2)
scatter2 = ax2.scatter(df['age'], df['annual_spending'], 
                      c=df['cluster'], cmap='viridis',
                      alpha=0.6, edgecolors='k', s=80)
ax2.set_xlabel('Age')
ax2.set_ylabel('Annual Spending ($)')
ax2.set_title('Customer Segments: Age vs Spending')
ax2.grid(True, alpha=0.3)

# Age vs Frequency
ax3 = plt.subplot(2, 3, 3)
scatter3 = ax3.scatter(df['age'], df['purchase_frequency'], 
                      c=df['cluster'], cmap='viridis',
                      alpha=0.6, edgecolors='k', s=80)
ax3.set_xlabel('Age')
ax3.set_ylabel('Purchase Frequency')
ax3.set_title('Customer Segments: Age vs Frequency')
ax3.grid(True, alpha=0.3)

# Cluster size distribution
ax4 = plt.subplot(2, 3, 4)
cluster_counts = df['cluster'].value_counts().sort_index()
bars = ax4.bar(cluster_counts.index, cluster_counts.values, 
               color=plt.cm.viridis(np.linspace(0, 1, optimal_k)),
               edgecolor='black', alpha=0.7)
ax4.set_xlabel('Cluster')
ax4.set_ylabel('Number of Customers')
ax4.set_title('Cluster Size Distribution')
ax4.set_xticks(range(optimal_k))
ax4.grid(True, alpha=0.3, axis='y')

# Add value labels on bars
for i, (idx, val) in enumerate(cluster_counts.items()):
    ax4.text(idx, val + 1, str(val), ha='center', va='bottom', fontweight='bold')

# Average spending by cluster
ax5 = plt.subplot(2, 3, 5)
avg_spending = df.groupby('cluster')['annual_spending'].mean().sort_index()
bars = ax5.bar(avg_spending.index, avg_spending.values,
               color=plt.cm.viridis(np.linspace(0, 1, optimal_k)),
               edgecolor='black', alpha=0.7)
ax5.set_xlabel('Cluster')
ax5.set_ylabel('Average Annual Spending ($)')
ax5.set_title('Average Spending by Cluster')
ax5.set_xticks(range(optimal_k))
ax5.grid(True, alpha=0.3, axis='y')

# Add value labels
for i, (idx, val) in enumerate(avg_spending.items()):
    ax5.text(idx, val + 100, f'${val:,.0f}', ha='center', va='bottom', fontweight='bold', fontsize=9)

# Average frequency by cluster
ax6 = plt.subplot(2, 3, 6)
avg_frequency = df.groupby('cluster')['purchase_frequency'].mean().sort_index()
bars = ax6.bar(avg_frequency.index, avg_frequency.values,
               color=plt.cm.viridis(np.linspace(0, 1, optimal_k)),
               edgecolor='black', alpha=0.7)
ax6.set_xlabel('Cluster')
ax6.set_ylabel('Average Purchase Frequency')
ax6.set_title('Average Purchase Frequency by Cluster')
ax6.set_xticks(range(optimal_k))
ax6.grid(True, alpha=0.3, axis='y')

# Add value labels
for i, (idx, val) in enumerate(avg_frequency.items()):
    ax6.text(idx, val + 0.5, f'{val:.1f}', ha='center', va='bottom', fontweight='bold')

plt.suptitle('Customer Segmentation Analysis - K-Means Clustering', 
             fontsize=16, fontweight='bold', y=0.995)
plt.tight_layout()
plt.savefig('/home/claude/cluster_visualization.png', dpi=300, bbox_inches='tight')
print("   Cluster visualization saved as 'cluster_visualization.png'")

# Save results to CSV
print("\n9. SAVING RESULTS...")

# Add cluster names to dataframe
df['cluster_name'] = df['cluster'].map(cluster_names)

# Save full dataset with cluster assignments
df.to_csv('/home/claude/customer_segmentation_results.csv', index=False)
print("   Results saved to 'customer_segmentation_results.csv'")

# Create summary report
summary_df = df.groupby('cluster').agg({
    'cluster_name': 'first',
    'annual_spending': ['mean', 'std', 'min', 'max'],
    'purchase_frequency': ['mean', 'std', 'min', 'max'],
    'age': ['mean', 'std', 'min', 'max']
}).round(2)

summary_df['count'] = df.groupby('cluster').size()
summary_df.to_csv('/home/claude/cluster_summary_statistics.csv')
print("   Summary statistics saved to 'cluster_summary_statistics.csv'")

# Final summary
print("\n" + "=" * 80)
print("SEGMENTATION SUMMARY:")
print("=" * 80)
print(f"✅ Successfully segmented {len(df)} customers into {optimal_k} distinct groups")
print(f"\n📊 CLUSTER BREAKDOWN:")

for cluster_id in range(optimal_k):
    cluster_data = df[df['cluster'] == cluster_id]
    pct = len(cluster_data) / len(df) * 100
    avg_value = cluster_data['annual_spending'].mean()
    total_value = cluster_data['annual_spending'].sum()
    
    print(f"\n   {cluster_names[cluster_id]}:")
    print(f"      • Size: {len(cluster_data)} customers ({pct:.1f}%)")
    print(f"      • Avg Value: ${avg_value:,.2f}/year")
    print(f"      • Total Revenue: ${total_value:,.2f}/year")

total_revenue = df['annual_spending'].sum()
print(f"\n💰 TOTAL CUSTOMER BASE VALUE: ${total_revenue:,.2f}/year")

print("\n🎯 KEY BUSINESS INSIGHTS:")
print("   1. Focus retention efforts on High-Value VIPs (highest revenue per customer)")
print("   2. Develop programs to move Regular Shoppers → VIP tier")
print("   3. Re-engagement campaigns for Occasional Buyers (largest growth potential)")
print("   4. Budget Customers: Low-cost acquisition, focus on volume")

print("\n" + "=" * 80)
print("CUSTOMER SEGMENTATION COMPLETE!")
print("=" * 80)
print("\nFiles generated:")
print("  • customer_segmentation_results.csv (full data with cluster assignments)")
print("  • cluster_summary_statistics.csv (statistical summary by cluster)")
print("  • customer_raw_data_visualization.png (initial data exploration)")
print("  • elbow_plot.png (K selection justification)")
print("  • cluster_visualization.png (comprehensive cluster analysis)")
print("\n✅ Ready for targeted marketing campaigns!")
